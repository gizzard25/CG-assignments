#include <stdio.h>
#include <iostream>
#include <sstream>
#include <stdlib.h>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>


#include <glew.h>

// GLFW
#include <glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtc/quaternion.hpp>
#include <glm/gtx/quaternion.hpp>
using namespace glm;
using namespace std;
/////////////////////////////////////
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void do_movement();

// Window dimensions

const GLuint WIDTH = 800, HEIGHT = 600;
glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 3.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
bool keys[1024];
GLfloat _yaw = -90.0f;
GLfloat _pitch = 0.0f;
GLfloat lastX = WIDTH / 2.0;
GLfloat lastY = HEIGHT / 2.0;
GLfloat near=1.0f;
GLfloat far=3000.0f;
GLfloat red = 1.0f;
GLfloat green = 1.0f;
GLfloat blue= 1.0f;
int mode;
int face;
int cFace;
string str;


//////////////////////////////////////////////
// Shaders
const GLchar* vertexShaderSource = "#version 330 core\n"
"layout (location = 0) in vec3 position;\n"
"layout (location = 1) in vec2 texture;\n"
"layout(location = 2) in vec3  normal;\n"
"uniform mat4 view;\n"
"uniform mat4 model;\n"
"uniform mat4 projection;\n"
"uniform mat4 lightspace;\n"
"void main()\n"
"{\n"
"gl_Position =lightspace*model*vec4(position.x, position.y, position.z, 1.0);\n"
"}\n\0";
const GLchar* fragmentShaderSource = "#version 330 core\n"
"out vec4 color;\n"
"void main()\n"
"{\n"
"color = vec4(1.0f);\n"
"}\n\0";

//////////////////////////////////////////////
struct Vertex {
	// Position
	glm::vec3 Position;
	// Normal
	glm::vec3 Normal;
	// TexCoords
	glm::vec2 TexCoords;
};
vector<Vertex> vertices;
void load_obj(string obj_path, vector<Vertex> &vertices);
///////////////////////////////////////////////
int main() {
	///////////////////////////////////initialize///////////////////
	if (!glfwInit())
	{
		fprintf(stderr, "f to initialize GLFW \n");
		return -1;
	}
	glfwWindowHint(GLFW_SAMPLES, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	glfwWindowHint(GLFW_RESIZABLE, GL_FALSE);

	///////////////////////////////////////////////////////////

	GLFWwindow* window;
	window = glfwCreateWindow(WIDTH, HEIGHT, "hh", NULL, NULL);
	if (window == NULL) {
		fprintf(stderr, "F TO OPEN GLFW WINDOW \n");
		glfwTerminate();
		return -1;
	}

	glfwMakeContextCurrent(window);
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
	glfwSetKeyCallback(window, key_callback);
	glfwSetCursorPosCallback(window, mouse_callback);
	glewExperimental = true;

	if (glewInit() != GLEW_OK) { fprintf(stderr, "FAIL TO INITIALIZE GLEW\n"); return -1; }
	glViewport(0, 0, WIDTH, HEIGHT);
	/////////////////////////////////////////
	
  
 
	cout<<"enter path:";
	cin>>str;
	cout<<"Please enter mode: 1 for point, 2 for line, 3 for polygon";
	cin>>mode;
	cout << "Please enter culling face mode: 1 for front face, 2 for back face :";
	cin >> cFace;
	cout << "Please enter face orientation: 1 for CW, 2 for CCW :";
	cin >> face;

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);

	if(face==1) glCullFace(GL_FRONT);
	else glCullFace(GL_BACK);

	if (cFace == 1) glFrontFace(GL_CW);
	 else glFrontFace(GL_CCW);

	//////////////////////////////////////////////////load .obj
	
	load_obj(str, vertices);
	//////////////////////////////////////////////find the central point 
	GLfloat min_x, max_x, min_y, max_y;
	min_x = max_x = vertices[0].Position.x;
	min_y = max_y = vertices[0].Position.y;
	for (unsigned int i = 1;i <= vertices.size() - 1;i++)
	{
		if (min_x>vertices[i].Position.x) min_x = vertices[i].Position.x;
		if (max_x<vertices[i].Position.x) max_x = vertices[i].Position.x;
		if (min_y>vertices[i].Position.y) min_y = vertices[i].Position.y;
		if (max_y<vertices[i].Position.y) max_y = vertices[i].Position.y;
	}
	GLfloat center_x = (min_x + max_x) / 2;
	GLfloat center_y = (min_y + max_y) / 2;
	///////////////////////////////////
	GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
	glCompileShader(vertexShader);
	// Check for compile time errors
	GLint success;
	GLchar infoLog[512];
	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(vertexShader, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;
	}
	// Fragment shader
	GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
	glCompileShader(fragmentShader);
	// Check for compile time errors
	glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(fragmentShader, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;
	}
	// Link shaders
	GLuint shaderProgram = glCreateProgram();
	glAttachShader(shaderProgram, vertexShader);
	glAttachShader(shaderProgram, fragmentShader);
	glLinkProgram(shaderProgram);
	// Check for linking errors
	glGetProgramiv(shaderProgram, GL_LINK_STATUS, &success);
	if (!success) {
		glGetProgramInfoLog(shaderProgram, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;
	}
	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);
	///////////////////////////////////////////


	GLuint vertexbuffer, VAO;
	glGenVertexArrays(1, &VAO);
	glBindVertexArray(VAO);
	// Generate 1 buffer, put the resulting identifier in vertexbuffer
	glGenBuffers(1, &vertexbuffer);
	// The following commands will talk about our 'vertexbuffer' buffer
	glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer);
	// Give our vertices to OpenGL.
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices)*vertices.size(), &vertices[0], GL_STATIC_DRAW);
	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(vertices), (GLvoid*)0);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(vertices), (GLvoid*)(3 * sizeof(GLfloat)));
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(vertices), (GLvoid*)(5 * sizeof(GLfloat)));
	// Draw the triangle !
	glEnableVertexAttribArray(0);
	glEnableVertexAttribArray(1);
	glEnableVertexAttribArray(2);
	glBindVertexArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	// Starting from vertex 0; 3 vertices total -> 1 triangle
	//glDisableVertexAttribArray(0);

	const GLuint SHADOW_WIDTH = 1024, SHADOW_HEIGHT = 1024;
	GLuint depthMapFBO;
	glGenFramebuffers(1, &depthMapFBO);
	// - Create depth texture
	GLuint depthMap;
	glGenTextures(1, &depthMap);
	glBindTexture(GL_TEXTURE_2D, depthMap);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, SHADOW_WIDTH, SHADOW_HEIGHT, 0, GL_DEPTH_COMPONENT, GL_FLOAT, NULL);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
	GLfloat borderColor[] = { 1.0, 1.0, 1.0, 1.0 };
	glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, borderColor);

	glBindFramebuffer(GL_FRAMEBUFFER, depthMapFBO);
	glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, depthMap, 0);
	glDrawBuffer(GL_NONE);
	glReadBuffer(GL_NONE);
	glBindFramebuffer(GL_FRAMEBUFFER, 0);

	glClearColor(0.1f, 0.1f, 0.1f, 1.0f);

////////////////////////////////////////////////
	glfwSetInputMode(window, GLFW_STICKY_KEYS, GL_TRUE);
	
	do
	{
		glfwPollEvents();
		glViewport(0, 0, SHADOW_WIDTH, SHADOW_HEIGHT);
	//	glBindFramebuffer(GL_FRAMEBUFFER, depthMapFBO);
		glUseProgram(shaderProgram);
		do_movement();
		////////////////////////
		glm::mat4 lightProjection, lightView;
		glm::mat4 lightspace;
		GLfloat near_plane = 1.0f, far_plane = 7.5f;
		lightProjection = glm::ortho(-10.0f, 10.0f, -10.0f, 10.0f, near_plane, far_plane);
		//lightProjection = glm::perspective(45.0f, (GLfloat)SHADOW_WIDTH / (GLfloat)SHADOW_HEIGHT, near_plane, far_plane); // Note that if you use a perspective projection matrix you'll have to change the light position as the current light position isn't enough to reflect the whole scene.
		lightView = glm::lookAt(vec3(5.0f, 6.0f, 3.0f), glm::vec3(0.0f), glm::vec3(0.0, 1.0, 0.0));
		lightspace = lightProjection * lightView;
		//////////////////////////////////////////////
		glBindVertexArray(VAO);

		glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "lightSpaceMatrix"), 1, GL_FALSE, glm::value_ptr(lightspace));

		////////////////////
		mat4 view;
		view = lookAt(cameraPos, cameraFront + cameraPos, cameraUp);
		GLint viewLoc = glGetUniformLocation(shaderProgram, "view");
		glUniformMatrix4fv(viewLoc, 1, GL_FALSE, value_ptr(view));
		///////////////////
		mat4 model;
		model = translate(vec3(-center_x, -center_y, 0.0f));
		//model=mat4(1.0f);
		GLint modelLoc = glGetUniformLocation(shaderProgram, "model");
		glUniformMatrix4fv(modelLoc, 1, GL_FALSE, value_ptr(model));
		///////////////////////////////////
		mat4 projection = perspective(45.0f, (GLfloat)WIDTH / (GLfloat)HEIGHT, near, far);
		GLint projectLoc = glGetUniformLocation(shaderProgram, "projection");
		glUniformMatrix4fv(projectLoc, 1, GL_FALSE, value_ptr(projection));
		///////////////////////////////////
	
		if(mode==1) glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);
		else if(mode==2) glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		else  glPolygonMode(GL_FRONT_AND_BACK, GL_POLYGON);
		
		
		glfwSwapBuffers(window);
		glClearColor(0.2f, 0.3f, 1.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT); //
															//
		//glPolygonMode(GL_FRONT_AND_BACK, GL_POLYGON);
		glDrawArrays(GL_TRIANGLES, 0, (GLsizei)vertices.size());
		glBindVertexArray(0);
	//	glBindFramebuffer(GL_FRAMEBUFFER,0);

	} while (glfwGetKey(window, GLFW_KEY_Y) != GLFW_PRESS);
	
	glDeleteVertexArrays(1, &VAO);
	glDeleteBuffers(1, &vertexbuffer);
	glfwTerminate();
	return 0;

} 
///////////////////////////////////////

void load_obj(string obj_path, vector<Vertex> &vertices) {
	std::vector<glm::vec3> positions;
	std::vector<glm::vec3> normals;
	std::vector<glm::vec2> tex_coods;
	ifstream ifs;
	try {
		ifs.open(obj_path);
		string one_line;
		while (getline(ifs, one_line)) {
			stringstream ss(one_line);
			string type;
			ss >> type;
			if (type == "v") {
				glm::vec3 vert_pos;
				ss >> vert_pos[0] >> vert_pos[1] >> vert_pos[2];
				positions.push_back(vert_pos);
			}
			else if (type == "vt") {
				glm::vec2 tex_coord;
				ss >> tex_coord[0] >> tex_coord[1];
				tex_coods.push_back(tex_coord);
			}
			else if (type == "vn") {
				glm::vec3 vert_norm;
				ss >> vert_norm[0] >> vert_norm[1] >> vert_norm[2];
				normals.push_back(vert_norm);
			}
			else if (type == "f") {
				string s_vertex_0, s_vertex_1, s_vertex_2;
				ss >> s_vertex_0 >> s_vertex_1 >> s_vertex_2;
				int pos_idx, tex_idx, norm_idx;
				sscanf_s(s_vertex_0.c_str(), "%d/%d/%d", &pos_idx, &tex_idx, &norm_idx);
				// We have to use index -1 because the obj index starts at 1
				Vertex vertex_0;
				vertex_0.Position = positions[pos_idx - 1];
				vertex_0.TexCoords = tex_coods[tex_idx - 1];
				vertex_0.Normal = normals[norm_idx - 1];
				sscanf_s(s_vertex_1.c_str(), "%d/%d/%d", &pos_idx, &tex_idx, &norm_idx);
				Vertex vertex_1;
				vertex_1.Position = positions[pos_idx - 1];
				vertex_1.TexCoords = tex_coods[tex_idx - 1];
				vertex_1.Normal = normals[norm_idx - 1];
				sscanf_s(s_vertex_2.c_str(), "%d/%d/%d", &pos_idx, &tex_idx, &norm_idx);
				Vertex vertex_2;
				vertex_2.Position = positions[pos_idx - 1];
				vertex_2.TexCoords = tex_coods[tex_idx - 1];
				vertex_2.Normal = normals[norm_idx - 1];
				vertices.push_back(vertex_0);
				vertices.push_back(vertex_1);
				vertices.push_back(vertex_2);
			}

		}
	}
	catch (const std::exception&) {
		cout << "Error: Obj file cannot be read\n";
	}
}

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode)
{
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		glfwSetWindowShouldClose(window, GL_TRUE);
	if (key >= 0 && key < 1024)
	{
		if (action == GLFW_PRESS)
			keys[key] = true;
		else if (action == GLFW_RELEASE)
			keys[key] = false;
	}
}

void do_movement()
{
	// Camera controls
	GLfloat cameraSpeed = 0.01f;
	if (keys[GLFW_KEY_W])
		cameraPos += cameraSpeed * cameraFront;
	if (keys[GLFW_KEY_S])
		cameraPos -= cameraSpeed * cameraFront;
	if (keys[GLFW_KEY_A])
		cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
	if (keys[GLFW_KEY_D])
		cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
	if (keys[GLFW_KEY_UP])
		cameraPos += cameraSpeed * cameraUp;
	if (keys[GLFW_KEY_DOWN])
		cameraPos -= cameraSpeed * cameraUp;
	if (keys[GLFW_KEY_R]){
		cameraPos = vec3(0.0f, 0.0f, 3.0f);
		 cameraFront = vec3(0.0f, 0.0f, -1.0f);
		 cameraUp = vec3(0.0f, 1.0f, 0.0f);
	}
	if(keys[GLFW_KEY_T]){
	 cin>>near;
	 cin>>far; 
	}
	if(keys[GLFW_KEY_C]){
	  cin>>red>>green>>blue;
	}
		
			
}
bool firstMouse = true;
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
	if (firstMouse)
	{
		lastX = xpos;
		lastY = ypos;
		firstMouse = false;
	}

	GLfloat xoffset = xpos - lastX;
	GLfloat yoffset = lastY - ypos; // Reversed since y-coordinates go from bottom to left
	lastX = xpos;
	lastY = ypos;

	GLfloat sensitivity = 0.05;	// Change this value to your liking
	xoffset *= sensitivity;
	yoffset *= sensitivity;

	_yaw += xoffset;
	_pitch += yoffset;

	// Make sure that when pitch is out of bounds, screen doesn't get flipped
	if (_pitch > 89.0f)
		_pitch = 89.0f;
	if (_pitch < -89.0f)
		_pitch = -89.0f;

	glm::vec3 front;
	front.x = cos(radians(_yaw)) * cos(radians(_pitch));
	front.y = sin(radians(_pitch));
	front.z = sin(radians(_yaw)) * cos(radians(_pitch));
	cameraFront = glm::normalize(front);
}
